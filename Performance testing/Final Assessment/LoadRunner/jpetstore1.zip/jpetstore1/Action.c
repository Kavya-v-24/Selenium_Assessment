Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='BIRDS' Name ='c_category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=c_category",
		"RegExp=categories/(.*?)\">",
		//"ORD=ALL",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	lr_start_transaction("launchapp");

	web_concurrent_start(NULL);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(14);

	web_websocket_send("ID=1", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790827024938\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive0*/

	lr_end_transaction("launchapp",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("category");

/*Correlation comment - Do not change!  Original value='AV-CB-01' Name ='c_productid' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=c_productid",
		"RegExp=products/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Birds",
		"URL=https://jpetstore.aspectran.com/categories/{c_category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t5.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("category",LR_AUTO);

	lr_think_time(28);

	lr_start_transaction("product");

/*Correlation comment - Do not change!  Original value='EST-18' Name ='c_itemId' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=c_itemId",
		"RegExp=items/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("AV-CB-01",
		"URL=https://jpetstore.aspectran.com/products/{c_productid}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{c_category}",
		"Snapshot=t6.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("product",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("item");

	web_url("EST-18",
		"URL=https://jpetstore.aspectran.com/products/{c_productid}/items/{c_itemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{c_productid}",
		"Snapshot=t7.inf",
		"Mode=HTTP",
		LAST);

	web_url("bird2.gif",
		"URL=https://jpetstore.aspectran.com/images/bird2.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://jpetstore.aspectran.com/products/{c_productid}/items/{c_itemId}",
		"Snapshot=t8.inf",
		LAST);

	lr_end_transaction("item",LR_AUTO);

	lr_start_transaction("addtocart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={c_itemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{c_productid}/items/{c_itemId}",
		"Snapshot=t9.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("addtocart",LR_AUTO);

	lr_start_transaction("checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("checkout",LR_AUTO);

	lr_start_transaction("login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t12.inf", 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("continue",LR_AUTO);

	lr_start_transaction("confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("confirm",LR_AUTO);

	return 0;
}